create function "AppProgramNewOption_archive_function"() returns trigger
    language plpgsql
as
$$
BEGIN IF (TG_OP = 'DELETE') THEN INSERT INTO archive."AppProgramNewOption" SELECT user, now(), 3, OLD.*; ELSIF (TG_OP = 'UPDATE') THEN INSERT INTO archive."AppProgramNewOption" SELECT user, now(), 2, NEW.*; ELSIF (TG_OP = 'INSERT') THEN INSERT INTO archive."AppProgramNewOption" SELECT user, now(), 1, NEW.*; END IF; RETURN NULL; END;
$$;

alter function "AppProgramNewOption_archive_function"() owner to root;

